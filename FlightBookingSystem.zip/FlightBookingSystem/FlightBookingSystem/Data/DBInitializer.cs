﻿using FlightBookingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingSystem.Data
{
    public class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            //look for any flight.
            if (context.Flight.Any())
            {
                return; // DB has been seeded
            }

            var flight = new Flight[]
            {

                new Flight{FlightNo= "UIA 111", Destination_From="Kiev", Destination_To="Turkey", Departure=DateTime.Parse("2017-11-01"), Arrival=DateTime.Parse("2017-11-01"), Fare="$1000"},
                new Flight{FlightNo= "UIA 222", Destination_From="Kiev", Destination_To="London", Departure=DateTime.Parse("2017-11-01"), Arrival=DateTime.Parse("2017-11-01"), Fare="$1200"},
                new Flight{FlightNo= "UIA 333", Destination_From="Kiev", Destination_To="Paris", Departure=DateTime.Parse("2017-11-02"), Arrival=DateTime.Parse("2017-11-02"), Fare="$1400"},
                new Flight{FlightNo= "UIA 444", Destination_From="Kiev", Destination_To="Berlin", Departure=DateTime.Parse("2017-11-02"), Arrival=DateTime.Parse("2017-11-02"), Fare="$1600"},
                new Flight{FlightNo= "UIA 555", Destination_From="Kiev", Destination_To="Dubai", Departure=DateTime.Parse("2017-11-03"), Arrival=DateTime.Parse("2017-11-03"), Fare="$1800"},

                new Flight{FlightNo= "UIA 666", Destination_From="Kiev", Destination_To="Edinburgh", Departure=DateTime.Parse("2017-11-03"), Arrival=DateTime.Parse("2017-11-03"), Fare="$1000"},
                new Flight{FlightNo= "UIA 777", Destination_From="Kiev", Destination_To="Chicago", Departure=DateTime.Parse("2017-11-04"), Arrival=DateTime.Parse("2017-11-04"), Fare="$1200"},
                new Flight{FlightNo= "UIA 888", Destination_From="Kiev", Destination_To="San Diego", Departure=DateTime.Parse("2017-11-04"), Arrival=DateTime.Parse("2017-11-04"), Fare="$1400"},
                new Flight{FlightNo= "UIA 999", Destination_From="Edinburgh", Destination_To="Las Vegas", Departure=DateTime.Parse("2017-11-05"), Arrival=DateTime.Parse("2017-11-05"), Fare="$1600"},
                new Flight{FlightNo= "UIA 000", Destination_From="Edinburgh", Destination_To="New York", Departure=DateTime.Parse("2017-11-05"), Arrival=DateTime.Parse("2017-11-05"), Fare="$1800"},

                new Flight{FlightNo= "UIA 123", Destination_From="Turkey", Destination_To="Orlando", Departure=DateTime.Parse("2017-11-06"), Arrival=DateTime.Parse("2017-11-06"), Fare="$1000"},
                new Flight{FlightNo= "UIA 456", Destination_From="Turkey", Destination_To="San Francisco", Departure=DateTime.Parse("2017-11-06"), Arrival=DateTime.Parse("2017-11-06"), Fare="$1200"},
                new Flight{FlightNo= "UIA 789", Destination_From="Turkey", Destination_To="Washington", Departure=DateTime.Parse("2017-11-07"), Arrival=DateTime.Parse("2017-11-07"), Fare="$1400"},
                new Flight{FlightNo= "UIA 012", Destination_From="Dubai", Destination_To="Barcelona", Departure=DateTime.Parse("2017-11-07"), Arrival=DateTime.Parse("2017-11-07"), Fare="$1600"},
                new Flight{FlightNo= "UIA 345", Destination_From="Dubai", Destination_To="Zurich", Departure=DateTime.Parse("2017-11-08"), Arrival=DateTime.Parse("2017-11-08"), Fare="$1800"},

                new Flight{FlightNo= "UIA 678", Destination_From="Sydney", Destination_To="Singapore", Departure=DateTime.Parse("2017-11-08"), Arrival=DateTime.Parse("2017-11-08"), Fare="$1000"},
                new Flight{FlightNo= "UIA 901", Destination_From="Sydney", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-09"), Arrival=DateTime.Parse("2017-11-09"), Fare="$1200"},
                new Flight{FlightNo= "UIA 234", Destination_From="Sydney", Destination_To="Vienna", Departure=DateTime.Parse("2017-11-09"), Arrival=DateTime.Parse("2017-11-09"), Fare="$1400"},
                new Flight{FlightNo= "UIA 567", Destination_From="Sydney", Destination_To="Brussels", Departure=DateTime.Parse("2017-11-10"), Arrival=DateTime.Parse("2017-11-10"), Fare="$1600"},
                new Flight{FlightNo= "UIA 890", Destination_From="Sydney", Destination_To="Sofia", Departure=DateTime.Parse("2017-11-10"), Arrival=DateTime.Parse("2017-11-10"), Fare="$1800"},
                
                new Flight{FlightNo= "UIA 112", Destination_From="Singapore", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-11"), Arrival=DateTime.Parse("2017-11-11"), Fare="$1000"},
                new Flight{FlightNo= "UIA 113", Destination_From="Singapore", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-11"), Arrival=DateTime.Parse("2017-11-11"), Fare="$1200"},
                new Flight{FlightNo= "UIA 114", Destination_From="Singapore", Destination_To="Paris", Departure=DateTime.Parse("2017-11-12"), Arrival=DateTime.Parse("2017-11-12"), Fare="$1400"},
                new Flight{FlightNo= "UIA 115", Destination_From="Brussels", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-12"), Arrival=DateTime.Parse("2017-11-12"), Fare="$1600"},
                new Flight{FlightNo= "UIA 116", Destination_From="Brussels", Destination_To="Dubai", Departure=DateTime.Parse("2017-11-13"), Arrival=DateTime.Parse("2017-11-13"), Fare="$1800"},

                new Flight{FlightNo= "UIA 117", Destination_From="Seoul", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-13"), Arrival=DateTime.Parse("2017-11-13"), Fare="$1000"},
                new Flight{FlightNo= "UIA 118", Destination_From="Seoul", Destination_To="Chicago", Departure=DateTime.Parse("2017-11-14"), Arrival=DateTime.Parse("2017-11-14"), Fare="$1200"},
                new Flight{FlightNo= "UIA 119", Destination_From="Seoul", Destination_To="San Diego", Departure=DateTime.Parse("2017-11-14"), Arrival=DateTime.Parse("2017-11-14"), Fare="$1400"},
                new Flight{FlightNo= "UIA 110", Destination_From="Barcelona", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-15"), Arrival=DateTime.Parse("2017-11-15"), Fare="$1600"},
                new Flight{FlightNo= "UIA 221", Destination_From="Barcelona", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-15"), Arrival=DateTime.Parse("2017-11-15"), Fare="$1800"},

                new Flight{FlightNo= "UIA 223", Destination_From="Barcelona", Destination_To="Orlando", Departure=DateTime.Parse("2017-11-16"), Arrival=DateTime.Parse("2017-11-16"), Fare="$1000"},
                new Flight{FlightNo= "UIA 224", Destination_From="Orlando", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-16"), Arrival=DateTime.Parse("2017-11-16"), Fare="$1200"},
                new Flight{FlightNo= "UIA 225", Destination_From="Orlando", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-17"), Arrival=DateTime.Parse("2017-11-17"), Fare="$1400"},
                new Flight{FlightNo= "UIA 226", Destination_From="Orlando", Destination_To="Barcelona", Departure=DateTime.Parse("2017-11-17"), Arrival=DateTime.Parse("2017-11-17"), Fare="$1600"},
                new Flight{FlightNo= "UIA 227", Destination_From="Orlando", Destination_To="Zurich", Departure=DateTime.Parse("2017-11-18"), Arrival=DateTime.Parse("2017-11-18"), Fare="$1800"},

                new Flight{FlightNo= "UIA 228", Destination_From="Vienna", Destination_To="Kuala Lumpur", Departure=DateTime.Parse("2017-11-18"), Arrival=DateTime.Parse("2017-11-18"), Fare="$1000"},
                new Flight{FlightNo= "UIA 229", Destination_From="Vienna", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-19"), Arrival=DateTime.Parse("2017-11-19"), Fare="$1200"},
                new Flight{FlightNo= "UIA 331", Destination_From="Vienna", Destination_To="Vienna", Departure=DateTime.Parse("2017-11-19"), Arrival=DateTime.Parse("2017-11-19"), Fare="$1400"},
                new Flight{FlightNo= "UIA 332", Destination_From="Kuala Lumpur", Destination_To="Seoul", Departure=DateTime.Parse("2017-11-20"), Arrival=DateTime.Parse("2017-11-20"), Fare="$1600"},
                new Flight{FlightNo= "UIA 334", Destination_From="Kuala Lumpur", Destination_To="Sofia", Departure=DateTime.Parse("2017-11-20"), Arrival=DateTime.Parse("2017-11-20"), Fare="$1800"},
            };

            foreach (Flight f in flight)
            {
                context.Flight.Add(f);
            }
            context.SaveChanges();
        }
    }
}
