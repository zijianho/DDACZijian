﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace FlightBookingSystem.Data.Migrations
{
    public partial class Book : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "userId",
                table: "Book",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Book_userId",
                table: "Book",
                column: "userId");

            migrationBuilder.AddForeignKey(
                name: "FK_Book_AspNetUsers_userId",
                table: "Book",
                column: "userId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Book_AspNetUsers_userId",
                table: "Book");

            migrationBuilder.DropIndex(
                name: "IX_Book_userId",
                table: "Book");

            migrationBuilder.DropColumn(
                name: "userId",
                table: "Book");
        }
    }
}
