﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingSystem.Models
{
    public class Flight
    {
        public int ID { get; set; }
        [Display(Name = "Flight Number")]
        public string FlightNo { get; set; }
        [Display(Name = "Destination From")]
        public string Destination_From { get; set; }
        [Display(Name = "Destination To")]
        public string Destination_To { get; set; }
        [Display(Name = "Departure")]
        public DateTime Departure { get; set; }
        [Display(Name = "Arrival")]
        public DateTime Arrival { get; set; }
        [Display(Name = "Fare")]
        public string Fare { get; set; }
        public ICollection<Flight> Flights { get; set; }
    }
}
